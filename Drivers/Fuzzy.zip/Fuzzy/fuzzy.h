#ifndef _FUZZY_H_
#define _FUZZY_H_


__ramfunc float Fuzzy(float P,float D);
float Fuzzy_Single(float P,float D);

#endif
